

#include <iostream>
 // Tema cu PUSH DOWN 
// sau alegem interfata grafica pentru un automat

int main()
{
    std::cout << "Hello World!\n";
}
